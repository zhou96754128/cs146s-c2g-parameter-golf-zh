# C2G 提交物（真实实测版）

- 优化器：Muon(2D hidden) + AdamW(emb/head/1D)
- seed：20261007｜steps：600｜batch：16｜block：256
- 参数量：3,346,944｜fp32 权重：13,387,776 字节
- 模型文件：model.pt（13,398,900 字节，上限 16,000,000）
- 本机缩小规模 val BPB：2.206367
- 语料：wikitext-2-raw-v1 (Salesforce/wikitext, Apache-2.0)
- 硬件：cpu（macOS-26.5-arm64-arm-64bit）

## 诚实边界
本产物**不是** 8×H100 10 分钟设定下的榜单成绩。它是缩小规模的真实对照实验产物，用于证明：(1) BPB 评测链路真实可跑；(2) Muon 单点改进在受控条件下相对 AdamW 有稳定收益；(3) 模型文件满足 ≤16,000,000 字节硬约束。

## 复现
```
python3 data_prep.py          # 下载并构造 wikitext-2 byte-level 语料
python3 run_sweep.py          # AdamW/Muon × 3 seed 对照（含 lr 探针）
python3 export_submission.py <out.tar.gz> <out.json> <members_dir>
```
